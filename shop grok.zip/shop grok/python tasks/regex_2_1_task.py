import re
product_count_text = "381 Products found"
product_count_int = int("".join(re.findall(r'[0-9]',product_count_text)))
print("numerical product count :",product_count_int)
